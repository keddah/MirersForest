#pragma once

#include "Collider.h"


class DeathBarrier : public Collision
{

};
#include "SceneManager.h"

#include "GameSingletons.h"

SceneManager::SceneManager()
{
	renderers.push_back(player.GetRenderer());
	StartGame();
}

SceneManager::~SceneManager()
{
}

void SceneManager::Update(float deltaTime)
{
	player.Update(deltaTime);
	collisionManager.Update();
	// print("rect: (" << colliders[0].GetRect().x<< ", " << colliders[0].GetRect().y << ", " << colliders[0].GetRect().w << ", " << colliders[0].GetRect().h << ")\n")
}

void SceneManager::Draw()
{
	for (auto& renderer : renderers)
	{
		renderer.Animate();
	}

	collisionManager.Debug();
}

void SceneManager::StartGame()
{
	collisionManager.AddCollider(player.GetCollider());
	
	_floor1 = Collision(100,0,100,1100);
	_floor2 = Collision(90,0,100,1100);
	collisionManager.AddCollider(_floor1);	
	collisionManager.AddCollider(_floor2);
	
}

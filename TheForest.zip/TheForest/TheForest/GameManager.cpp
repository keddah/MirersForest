#include "GameManager.h"

// Initialise SDL in this constructer
GameManager::GameManager()
{
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		std::cout << "could not initialize SDL2!" << std::endl;
		std::cout << SDL_GetError() << std::endl;
		return;
	}

	GameWindow::SetWindow
	(
		SDL_CreateWindow
		(
		"Mirer's Forest",
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		screenWidth, screenHeight,
		SDL_WINDOW_SHOWN
		)
	);
	if (!GameWindow::GetWindow())
	{
		std::cout << "could not initialise window!" << std::endl;
		std::cout << SDL_GetError() << std::endl;
		return;
	}

	GameWindow::SetRenderer(SDL_CreateRenderer(GameWindow::GetWindow(), -1, SDL_RENDERER_ACCELERATED));
	if (!GameWindow::GetRenderer())
	{
		std::cout << "could not initialise window!" << std::endl;
		std::cout << SDL_GetError() << std::endl;
		return;
	}
	SDL_RenderSetVSync(GameWindow::GetRenderer(), 1);

	session = std::unique_ptr<GameSession>(new GameSession());
	running = true;
}

GameManager::~GameManager()
{
	SDL_DestroyRenderer(GameWindow::GetRenderer());
	SDL_DestroyWindow(GameWindow::GetWindow());
	SDL_Quit();
}

// Gets called in a while loop in the main function
void GameManager::Update()
{
	// Update all the things that need to be updated for the current session.
	session->Update(Time::GetDeltaTime());
}

void GameManager::FixedUpdate()
{
	session->FixedUpdate(Time::GetDeltaTime());
}

void GameManager::Draw()
{
	SDL_SetRenderDrawColor(GameWindow::GetRenderer(), 0, 15, 10, 255);
	SDL_RenderFillRect(GameWindow::GetRenderer(), nullptr);

	// Clear the screen before rendering something new
	SDL_RenderClear(GameWindow::GetRenderer());

	// Render everything that needs to be rendered in the current session
	session->Draw();

	// Actually display the new things
	SDL_RenderPresent(GameWindow::GetRenderer());
}

bool GameManager::IsRunning() const
{
	return running;
}

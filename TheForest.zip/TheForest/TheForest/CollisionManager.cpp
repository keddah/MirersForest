#include "Collider.h"

void CollisionManager::Update() const
{
    for(int i = 0; i < colliders.size(); i++)
    {
        if(i > 0) colliders[i]->SetOverlapping(colliders[i]->Overlapping(colliders[i - 1]->GetRect()));
        else colliders[i]->SetOverlapping(colliders[i]->Overlapping(colliders.back()->GetRect()));
        print(i << ": " << colliders[i]->IsOverlapping())
    }
    
}


void CollisionManager::Debug() const
{
    for(const auto& collider:colliders) collider->Debug();
    
}


void CollisionManager::AddCollider(Collision& toAdd)
{
    colliders.push_back(&toAdd);
}
